--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.11 (Ubuntu 12.11-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.11 (Ubuntu 12.11-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE daoo;
--
-- Name: daoo; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE daoo WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE daoo OWNER TO root;

\connect daoo

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: descontos; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.descontos (
    id_desc integer NOT NULL,
    descricao character varying(200) NOT NULL,
    taxa numeric(10,2) DEFAULT 0.00 NOT NULL
);


ALTER TABLE public.descontos OWNER TO root;

--
-- Name: descontos_id_desc_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.descontos_id_desc_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.descontos_id_desc_seq OWNER TO root;

--
-- Name: descontos_id_desc_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.descontos_id_desc_seq OWNED BY public.descontos.id_desc;


--
-- Name: extras; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.extras (
    id_ext integer NOT NULL,
    descricao character varying(200) NOT NULL
);


ALTER TABLE public.extras OWNER TO root;

--
-- Name: extras_id_ext_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.extras_id_ext_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.extras_id_ext_seq OWNER TO root;

--
-- Name: extras_id_ext_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.extras_id_ext_seq OWNED BY public.extras.id_ext;


--
-- Name: prod_desc; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.prod_desc (
    id_prod integer NOT NULL,
    id_desc integer NOT NULL
);


ALTER TABLE public.prod_desc OWNER TO root;

--
-- Name: prod_ext; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.prod_ext (
    id_prod integer NOT NULL,
    id_ext integer NOT NULL
);


ALTER TABLE public.prod_ext OWNER TO root;

--
-- Name: produtos; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.produtos (
    id_prod integer NOT NULL,
    nome character varying(200) NOT NULL,
    descricao character varying(500) NOT NULL,
    qtd_estoque integer DEFAULT 0 NOT NULL,
    preco numeric(10,2) NOT NULL,
    importado smallint DEFAULT 0 NOT NULL
);


ALTER TABLE public.produtos OWNER TO root;

--
-- Name: produtos_id_prod_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.produtos_id_prod_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produtos_id_prod_seq OWNER TO root;

--
-- Name: produtos_id_prod_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.produtos_id_prod_seq OWNED BY public.produtos.id_prod;


--
-- Name: descontos id_desc; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.descontos ALTER COLUMN id_desc SET DEFAULT nextval('public.descontos_id_desc_seq'::regclass);


--
-- Name: extras id_ext; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.extras ALTER COLUMN id_ext SET DEFAULT nextval('public.extras_id_ext_seq'::regclass);


--
-- Name: produtos id_prod; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.produtos ALTER COLUMN id_prod SET DEFAULT nextval('public.produtos_id_prod_seq'::regclass);


--
-- Data for Name: descontos; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.descontos (id_desc, descricao, taxa) FROM stdin;
\.
COPY public.descontos (id_desc, descricao, taxa) FROM '$$PATH$$/2999.dat';

--
-- Data for Name: extras; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.extras (id_ext, descricao) FROM stdin;
\.
COPY public.extras (id_ext, descricao) FROM '$$PATH$$/3001.dat';

--
-- Data for Name: prod_desc; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.prod_desc (id_prod, id_desc) FROM stdin;
\.
COPY public.prod_desc (id_prod, id_desc) FROM '$$PATH$$/3003.dat';

--
-- Data for Name: prod_ext; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.prod_ext (id_prod, id_ext) FROM stdin;
\.
COPY public.prod_ext (id_prod, id_ext) FROM '$$PATH$$/3004.dat';

--
-- Data for Name: produtos; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.produtos (id_prod, nome, descricao, qtd_estoque, preco, importado) FROM stdin;
\.
COPY public.produtos (id_prod, nome, descricao, qtd_estoque, preco, importado) FROM '$$PATH$$/3005.dat';

--
-- Name: descontos_id_desc_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.descontos_id_desc_seq', 5, true);


--
-- Name: extras_id_ext_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.extras_id_ext_seq', 5, true);


--
-- Name: produtos_id_prod_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.produtos_id_prod_seq', 101, true);


--
-- Name: descontos descontos_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.descontos
    ADD CONSTRAINT descontos_pkey PRIMARY KEY (id_desc);


--
-- Name: extras extras_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.extras
    ADD CONSTRAINT extras_pkey PRIMARY KEY (id_ext);


--
-- Name: prod_desc prod_desc_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.prod_desc
    ADD CONSTRAINT prod_desc_pkey PRIMARY KEY (id_prod, id_desc);


--
-- Name: prod_ext prod_ext_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.prod_ext
    ADD CONSTRAINT prod_ext_pkey PRIMARY KEY (id_prod, id_ext);


--
-- Name: produtos produtos_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.produtos
    ADD CONSTRAINT produtos_pkey PRIMARY KEY (id_prod);


--
-- Name: prod_desc prod_desc_id_desc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.prod_desc
    ADD CONSTRAINT prod_desc_id_desc_fkey FOREIGN KEY (id_desc) REFERENCES public.descontos(id_desc) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: prod_desc prod_desc_id_prod_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.prod_desc
    ADD CONSTRAINT prod_desc_id_prod_fkey FOREIGN KEY (id_prod) REFERENCES public.produtos(id_prod) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: prod_ext prod_ext_id_ext_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.prod_ext
    ADD CONSTRAINT prod_ext_id_ext_fkey FOREIGN KEY (id_ext) REFERENCES public.extras(id_ext) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: prod_ext prod_ext_id_prod_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.prod_ext
    ADD CONSTRAINT prod_ext_id_prod_fkey FOREIGN KEY (id_prod) REFERENCES public.produtos(id_prod) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

